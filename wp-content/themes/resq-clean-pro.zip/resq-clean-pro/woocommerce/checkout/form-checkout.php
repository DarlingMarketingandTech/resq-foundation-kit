<?php
/**
 * Checkout form shell.
 *
 * Mirrors WooCommerce's standard checkout form structure, preserving all
 * action hooks. Adds resq-* classes and a compliance notice slot above
 * the customer details fields.
 *
 * @package ResQ_Clean_Pro
 *
 * @var WC_Checkout $checkout WooCommerce checkout instance.
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $checkout ) || ! is_a( $checkout, 'WC_Checkout' ) ) {
	return;
}

do_action( 'woocommerce_before_checkout_form', $checkout );

if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html(
		apply_filters(
			'woocommerce_checkout_must_be_logged_in_message',
			__( 'You must be logged in to checkout.', 'woocommerce' )
		)
	);
	return;
}

resq_theme_render_compliance_notices( 'checkout' );
?>
<form
	name="checkout"
	method="post"
	class="checkout woocommerce-checkout resq-checkout-form"
	action="<?php echo esc_url( wc_get_checkout_url() ); ?>"
	enctype="multipart/form-data"
>
	<?php if ( $checkout->get_checkout_fields() ) : ?>

		<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

		<div class="col2-set resq-checkout-customer" id="customer_details">
			<div class="col-1">
				<?php do_action( 'woocommerce_checkout_billing' ); ?>
			</div>
			<div class="col-2">
				<?php do_action( 'woocommerce_checkout_shipping' ); ?>
			</div>
		</div>

		<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

	<?php endif; ?>

	<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>

	<h3 id="order_review_heading"><?php esc_html_e( 'Your order', 'woocommerce' ); ?></h3>

	<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

	<div id="order_review" class="woocommerce-checkout-review-order resq-checkout-order-review">
		<?php do_action( 'woocommerce_checkout_order_review' ); ?>
	</div>

	<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
